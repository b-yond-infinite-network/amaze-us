
  
  // test.js
  jest.mock('mysql'); // this happens automatically with automocking
  const mockMysql = require('mysql');
  
 //console.log(mockMysql);