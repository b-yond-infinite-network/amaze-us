// @NamedQuery(name = "Reminders.findAll", query = "SELECT r FROM Reminders r")
//     , @NamedQuery(name = "Reminders.findById", query = "SELECT r FROM Reminders r WHERE r.id = :id")
//     , @NamedQuery(name = "Reminders.findByName", query = "SELECT r FROM Reminders r WHERE r.name = :name")
//     , @NamedQuery(name = "Reminders.findByDate", query = "SELECT r FROM Reminders r WHERE r.date = :date")
//     , @NamedQuery(name = "Reminders.findByIsComplete", query = "SELECT r FROM Reminders r WHERE r.isComplete = :isComplete")})

const mysql = require('mysql');
const promisify = require('util.promisify');

// connection.connect();

// connection.query('SELECT 1 + 1 AS solution', function (error, results, fields) {
//     if (error) throw error;
//     console.log('The solution is: ', results[0].solution);
// });

// connection.end();

class RemindersDAO {
  constructor(options){
    this.options = Object.assign({
      mysql: mysql
    }, options);
    // TODO: connection pool
    // TODO: KMS for credentials
    this.connect();
  }

  connect(){
    this.connection = this.options.mysql.createConnection({
      host     : 'jax-rs-db.cce8xk4qewtv.us-east-1.rds.amazonaws.com',
      user     : 'root',
      password : '12345678',
      database : 'reminders'
    });

    this.connection.connect();
    this.query = promisify(this.connection.query.bind(this.connection));
  }

  findAll(){
    let result;
    //this.connect();
    result = this.query('SELECT * FROM reminders r');
    //this.close();
    return result;
  }

  findByName(name){

  }

  findByDate(date){

  }

  findByIsComplete(isComplete){

  }

  close(){
    this.connection.end();
  }
}

module.exports = {
  create: (options) => new RemindersDAO(options)
};